    setInterval(function() {
    document.querySelector('button.t-button--theme-primary.t-is-disabled').removeAttribute('disabled');
    document.querySelector('button.t-button--theme-primary.t-is-disabled').className = 't-button t-button--variant-base t-button--theme-primary';
}, 200);